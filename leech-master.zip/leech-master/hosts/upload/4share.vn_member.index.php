<?
$upload_services[]="4share.vn_member";
$max_file_size["4share.vn_member"]= 200;
$page_upload["4share.vn_member"] = "4share.vn_member.php";
?>
