<?php
$upload_services[] = 'biggerupload.com';
$max_file_size['biggerupload.com'] = 200;
$page_upload['biggerupload.com'] = 'biggerupload.com.php';  
?>