<?php 
$upload_services[]="filesin.com_premium";
$max_file_size["filesin.com_premium"]=2048;
$page_upload["filesin.com_premium"] = "filesin.com_premium.php";  
?>
