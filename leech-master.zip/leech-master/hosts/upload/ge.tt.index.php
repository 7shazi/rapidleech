<?php
$upload_services[] = 'ge.tt';
$max_file_size['ge.tt'] = 2000;
$page_upload['ge.tt'] = 'ge.tt.php';
?>