<?php
$upload_services[]="rapidshare.ru";
$max_file_size["rapidshare.ru"]=1500;
$page_upload["rapidshare.ru"] = "rapidshare.ru.php";  

$rapidshareru_login=""; // <- �����/Login
$rapidshareru_pass=""; // <- ������/Password
?>