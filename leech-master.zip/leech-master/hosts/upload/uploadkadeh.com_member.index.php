<?php
$upload_services[] = 'uploadkadeh.com_member';
$max_file_size['uploadkadeh.com_member'] = 2048;
$page_upload['uploadkadeh.com_member'] = 'uploadkadeh.com_member.php';