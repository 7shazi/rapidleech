<?php
$upload_services[] = 'zippyshare.com';
$max_file_size['zippyshare.com'] = 500;
$page_upload['zippyshare.com'] = 'zippyshare.com.php';